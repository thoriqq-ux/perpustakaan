<?php
// autoloader
// untuk meload beberapa fungsi utama yang dibutuhkan
// agar require file tidak terlalu banyak di setiap file

require_once __DIR__."/../function/db.php";
